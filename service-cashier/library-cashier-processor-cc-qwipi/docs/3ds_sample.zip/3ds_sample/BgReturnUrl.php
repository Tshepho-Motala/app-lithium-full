<?php
  $operation = $_POST['operation'];
  $resultCode = $_POST['resultCode'];
  $errorCode = $_POST['errorCode'];
  $merNo = $_POST['merNo'];
  $billNo = $_POST['billNo'];
  $currency = $_POST['currency'];
  $amount = $_POST['amount'];
  $dateTime = $_POST['dateTime'];
  $orderId = $_POST['orderId'];
  $md5Info = $_POST['md5Info'];
  $remark = $_POST['remark'];
  $billingDescriptor = $_POST['billingDescriptor'];
  echo "Got Callback for: billNo=".$billNo;
?>
