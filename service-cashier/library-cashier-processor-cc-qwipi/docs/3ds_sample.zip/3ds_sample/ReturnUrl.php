<html>
<?php
  $operation = $_POST['operation'];
  $resultCode = $_POST['resultCode'];
  $errorCode = $_POST['errorCode'];
  $merNo = $_POST['merNo'];
  $billNo = $_POST['billNo'];
  $currency = $_POST['currency'];
  $amount = $_POST['amount'];
  $dateTime = $_POST['dateTime'];
  $orderId = $_POST['orderId'];
  $md5Info = $_POST['md5Info'];
  $remark = $_POST['remark'];
  $billingDescriptor = $_POST['billingDescriptor'];
?>
  <body>
    <table>
      <tr>
        <th colspan="4">Results for: <?php echo $billNo;?></th>
      </tr>
      <tr>
        <td>operation:</td><td><?php echo $operation; ?></td>
        <td>resultCode:</td><td><?php echo $resultCode; ?></td>
      </tr>
      <tr>
        <td>errorCode:</td><td><?php echo $errorCode; ?></td>
      </tr>
      <tr>
        <td>merNo:</td><td><?php echo $merNo; ?></td>
        <td>billNo:</td><td><?php echo $billNo; ?></td>
      </tr>
      <tr>
        <td>currency:</td><td><?php echo $currency; ?></td>
        <td>amount:</td><td><?php echo $amount; ?></td>
      </tr>
      <tr>
        <td>dateTime:</td><td><?php echo $dateTime; ?></td>
        <td>orderId:</td><td><?php echo $orderId;?></td>
      </tr>
      <tr>
        <td>md5Info:</td><td><?php echo $md5Info; ?></td>
        <td>billingDescriptor:</td><td><?php echo $billingDescriptor; ?></td>
      </tr>
      <tr>
        <td>remark:</td><td colspan="3"><?php echo $remark; ?></td>
      </tr>
    </table>
  </body>
</html>